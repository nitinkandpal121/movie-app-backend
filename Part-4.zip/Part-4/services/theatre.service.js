const { createTheatresValidationSchema } = require('../lib/validators/theatres.validators');
const Theatre = require('../models/theatre.model');

class TheatreService{

    static async getAll(){
        const theatres = await Theatre.find({});
        return theatres;
    }

    static async create(data){
        const safeParseData = await createTheatresValidationSchema.safeParseAsync(data);

        if(safeParseData.errors) throw new Error(safeParseData.errors);

        return await Theatre.create(safeParseData.data);
    }
}

module.exports=TheatreService;