const TheatreService = require('../services/theatre.service');
const { createTheatresValidationSchema} = require('../lib/validators/theatres.validators');


async function getAllTheatres(req,res){
    const theatres = await TheatreService.getAll();
    return res.json({data: theatres});
}

async function createTheatre(req,res){
    const validationResult = await createTheatresValidationSchema.safeParseAsync(req.body);

    if(validationResult.error) {
        return res.status(400).json({error: validationResult.error});
    }

    //const {name, plot, street, city, state, country, pincode, lat, lon} = validationResult.data;

    //const theatre = await TheatreService.create({name, plot, street, city, state, country, pincode, lat, lon});

    const theatre = await TheatreService.create(validationResult.data);

    return res.status(201).json({status:'success',data:theatre})

}

module.exports={
    getAllTheatres,
    createTheatre
}